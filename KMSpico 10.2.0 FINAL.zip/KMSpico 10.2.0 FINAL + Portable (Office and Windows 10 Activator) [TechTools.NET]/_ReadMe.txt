Instructions:
1) Stop the application if started
2) Install application using provided installer
3) Open it and activate your windows/office
DONE!
 

www.Techtools.net /  www.ThumperDC.com